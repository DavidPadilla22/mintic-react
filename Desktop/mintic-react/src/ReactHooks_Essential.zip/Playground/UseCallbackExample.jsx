import { useCallback } from "react";

export default function UseCallbackExample() {
  const log = useCallback(() => {
    console.log("Hola desde useCallback");
  }, []);

  return <button onClick={log}>Imprimir</button>;
}