import { Link } from "react-router-dom";

export default function PlaygroundMenu() {
  return (
    <div>
      <h1>Playground de Hooks</h1>
      <ul>
        <li><Link to="/playground/use-state">useState</Link></li>
        <li><Link to="/playground/use-effect">useEffect</Link></li>
        <li><Link to="/playground/use-ref">useRef</Link></li>
        <li><Link to="/playground/use-context">useContext</Link></li>
        <li><Link to="/playground/use-memo">useMemo</Link></li>
        <li><Link to="/playground/use-callback">useCallback</Link></li>
      </ul>
    </div>
  );
}