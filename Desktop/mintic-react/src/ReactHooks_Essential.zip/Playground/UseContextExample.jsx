import { createContext, useContext, useState } from "react";

const ColorContext = createContext();

function Child() {
  const color = useContext(ColorContext);
  return <div style={{ color }}>Este texto usa color global</div>;
}

export default function UseContextExample() {
  const [color] = useState("blue");

  return (
    <ColorContext.Provider value={color}>
      <Child />
    </ColorContext.Provider>
  );
}