import { useState } from "react";

export default function UseStateExample() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h2>Contador: {count}</h2>
      <button onClick={() => setCount(count + 1)}>Subir</button>
      <button onClick={() => setCount(count - 1)}>Bajar</button>
    </div>
  );
}