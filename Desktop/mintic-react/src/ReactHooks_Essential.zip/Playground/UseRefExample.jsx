import { useRef } from "react";

export default function UseRefExample() {
  const inputRef = useRef();

  const focusInput = () => {
    inputRef.current.focus();
  };

  return (
    <div>
      <input ref={inputRef} placeholder="Escribe algo" />
      <button onClick={focusInput}>Enfocar</button>
    </div>
  );
}