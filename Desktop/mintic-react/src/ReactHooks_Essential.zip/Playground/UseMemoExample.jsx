import { useState, useMemo } from "react";

export default function UseMemoExample() {
  const [num, setNum] = useState(1);
  const doble = useMemo(() => num * 2, [num]);

  return (
    <div>
      <input type="number" value={num} onChange={(e) => setNum(Number(e.target.value))} />
      <p>Doble: {doble}</p>
    </div>
  );
}