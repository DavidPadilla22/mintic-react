import { useState, useEffect } from "react";

export default function UseEffectExample() {
  const [value, setValue] = useState(0);

  useEffect(() => {
    console.log("El valor cambió a", value);
  }, [value]);

  return (
    <button onClick={() => setValue(value + 1)}>Cambiar valor</button>
  );
}